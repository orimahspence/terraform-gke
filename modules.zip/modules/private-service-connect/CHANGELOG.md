# Changelog

## [0.7.0](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.16...private-service-connect-v0.7.0) (2025-02-13)


### Features

* set the default max pods per node 32 ([#158](https://github.com/cvs-health-source-code/terraform-gke/issues/158)) ([23b53f3](https://github.com/cvs-health-source-code/terraform-gke/commit/23b53f3d6f058eca781660598349624411a7c40e))


### Bug Fixes

* trigger the commit set max pods per node for version ([#160](https://github.com/cvs-health-source-code/terraform-gke/issues/160)) ([741ac73](https://github.com/cvs-health-source-code/terraform-gke/commit/741ac73a3b3b119f3a17c05e7c180244eef668bc))

## [0.6.16](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.15...private-service-connect-v0.6.16) (2025-01-13)


### Bug Fixes

* remove pubsub creation and attach - static centralized topic ([#150](https://github.com/cvs-health-source-code/terraform-gke/issues/150)) ([6a25de5](https://github.com/cvs-health-source-code/terraform-gke/commit/6a25de5d1f3ce18dbe1be517bfbe5d607becb2b7))

## [0.6.15](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.14...private-service-connect-v0.6.15) (2024-12-17)


### Bug Fixes

* logging variant in all modules and typo on private-service-connect ([6b472ec](https://github.com/cvs-health-source-code/terraform-gke/commit/6b472ecaac44a6b00d75d63008509c4281af7262))

## [0.6.14](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.13...private-service-connect-v0.6.14) (2024-12-13)


### Bug Fixes

* adding max throughput to private service connect ([#145](https://github.com/cvs-health-source-code/terraform-gke/issues/145)) ([57f5358](https://github.com/cvs-health-source-code/terraform-gke/commit/57f5358106c2aa3b1b32faa84c4219da0f0b7e22))

## [0.6.13](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.12...private-service-connect-v0.6.13) (2024-08-26)


### Bug Fixes

* reconcile diffs ([#127](https://github.com/cvs-health-source-code/terraform-gke/issues/127)) ([2c2bab6](https://github.com/cvs-health-source-code/terraform-gke/commit/2c2bab60f25fa8409bd68282860919294533c480))

## [0.6.12](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.11...private-service-connect-v0.6.12) (2024-08-26)


### Bug Fixes

* ip allocation policy ([#124](https://github.com/cvs-health-source-code/terraform-gke/issues/124)) ([43206cc](https://github.com/cvs-health-source-code/terraform-gke/commit/43206cc373543f62262751f852f35447d87cafc7))

## [0.6.11](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.10...private-service-connect-v0.6.11) (2024-07-02)


### Bug Fixes

* Tf linux node config ([#112](https://github.com/cvs-health-source-code/terraform-gke/issues/112)) ([140cfec](https://github.com/cvs-health-source-code/terraform-gke/commit/140cfec1905beb023ad86654d9b33d9765edc564))

## [0.6.10](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.9...private-service-connect-v0.6.10) (2024-03-07)


### Bug Fixes

* update default max pods per node ([#106](https://github.com/cvs-health-source-code/terraform-gke/issues/106)) ([be38fe7](https://github.com/cvs-health-source-code/terraform-gke/commit/be38fe7a9cfa0273aa0e7275315c478dd6d36f3b))

## [0.6.9](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.8...private-service-connect-v0.6.9) (2024-01-18)


### Bug Fixes

* demo for jfrog module source ([#103](https://github.com/cvs-health-source-code/terraform-gke/issues/103)) ([470d22f](https://github.com/cvs-health-source-code/terraform-gke/commit/470d22f285875f867e78acdd2ec073395dda913e))

## [0.6.8](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.7...private-service-connect-v0.6.8) (2024-01-09)


### Bug Fixes

* fetch GKE nodes CIDR using data block to minimize required user input ([#100](https://github.com/cvs-health-source-code/terraform-gke/issues/100)) ([61a32f3](https://github.com/cvs-health-source-code/terraform-gke/commit/61a32f384530a7a9f384ddcc984a8dfdfa754ce3))
* fetch node, pods, svcs subnets ([#102](https://github.com/cvs-health-source-code/terraform-gke/issues/102)) ([222a221](https://github.com/cvs-health-source-code/terraform-gke/commit/222a221e75603d755ba48d97fb36065686d8780a))

## [0.6.7](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.6...private-service-connect-v0.6.7) (2024-01-09)


### Bug Fixes

* set cluster name as default tag for insurance-vpc clusters ([#98](https://github.com/cvs-health-source-code/terraform-gke/issues/98)) ([288efb0](https://github.com/cvs-health-source-code/terraform-gke/commit/288efb075ee4ced1cedfe7c1df41625aa12cd49a))

## [0.6.6](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.5...private-service-connect-v0.6.6) (2024-01-04)


### Bug Fixes

* add example for pulling tf module from jfrog ([#95](https://github.com/cvs-health-source-code/terraform-gke/issues/95)) ([6922286](https://github.com/cvs-health-source-code/terraform-gke/commit/69222863d9715b98d7d71621c497c2479628491a))
* add version for jfrog source ([ac83862](https://github.com/cvs-health-source-code/terraform-gke/commit/ac838622e283f90bc078381bf618ba4eb9522f28))

## [0.6.5](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.4...private-service-connect-v0.6.5) (2023-12-26)


### Bug Fixes

* testing publish to jfrog ([c51012a](https://github.com/cvs-health-source-code/terraform-gke/commit/c51012a201cf3c87ea9e47cab01af15d150583a3))
* testing publish to jfrog ([3884dc2](https://github.com/cvs-health-source-code/terraform-gke/commit/3884dc26263a5c5fd689afe2cc93e014656fe4a2))

## [0.6.4](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.3...private-service-connect-v0.6.4) (2023-12-08)


### Bug Fixes

* check for non-prod branch name for centralized cmek ([7740007](https://github.com/cvs-health-source-code/terraform-gke/commit/7740007450315c10ec4d0eaefcc8237d32b9f6e7))

## [0.6.3](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.2...private-service-connect-v0.6.3) (2023-12-08)


### Bug Fixes

* initial node count to not exahust ips ([#89](https://github.com/cvs-health-source-code/terraform-gke/issues/89)) ([14edff8](https://github.com/cvs-health-source-code/terraform-gke/commit/14edff8777c7fb32c33145e8042d82f8dc0455a8))

## [0.6.2](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.1...private-service-connect-v0.6.2) (2023-12-01)


### Bug Fixes

* update module version in examples ([#87](https://github.com/cvs-health-source-code/terraform-gke/issues/87)) ([17e1a43](https://github.com/cvs-health-source-code/terraform-gke/commit/17e1a4360352cb8867e0cad45cdbbe86a318069b))

## [0.6.1](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.6.0...private-service-connect-v0.6.1) (2023-11-30)


### Bug Fixes

* bugfix, rollback zscaler prod tags ([#84](https://github.com/cvs-health-source-code/terraform-gke/issues/84)) ([bee0252](https://github.com/cvs-health-source-code/terraform-gke/commit/bee0252ffac3240746cf1d3950395c1a26799ff6))
* remove local ssd creation option from main module ([#85](https://github.com/cvs-health-source-code/terraform-gke/issues/85)) ([69fa2a0](https://github.com/cvs-health-source-code/terraform-gke/commit/69fa2a0b321f059d62e3f67892feba1991ad3ca4))

## [0.6.0](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.5.0...private-service-connect-v0.6.0) (2023-11-22)


### Features

* initial terraform zscaler tagging plan ([#77](https://github.com/cvs-health-source-code/terraform-gke/issues/77)) ([fe5087a](https://github.com/cvs-health-source-code/terraform-gke/commit/fe5087ab79d18191b435bd5a87eb43cb4eb3b326))

## [0.5.0](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.4.6...private-service-connect-v0.5.0) (2023-11-17)


### Features

* Private psc (US1655384) ([#75](https://github.com/cvs-health-source-code/terraform-gke/issues/75)) ([d36c19f](https://github.com/cvs-health-source-code/terraform-gke/commit/d36c19f87e3aefbc138841c56d8c3fed7be6377f))

## [0.4.6](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.4.5...private-service-connect-v0.4.6) (2023-11-02)


### Bug Fixes

* remove project number ([#71](https://github.com/cvs-health-source-code/terraform-gke/issues/71)) ([8b0cb44](https://github.com/cvs-health-source-code/terraform-gke/commit/8b0cb448c9ad4801021742a3143332aab1abc757))

## [0.4.5](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.4.4...private-service-connect-v0.4.5) (2023-10-30)


### Bug Fixes

* disable managed prom ([4bfec0b](https://github.com/cvs-health-source-code/terraform-gke/commit/4bfec0bb4a26cab59f2d3f4b265d891c86843c42))

## [0.4.4](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.4.3...private-service-connect-v0.4.4) (2023-10-25)


### Bug Fixes

* remove components ([0bf3d68](https://github.com/cvs-health-source-code/terraform-gke/commit/0bf3d6827957bfbdd7a167911749ca0ccc4ee809))

## [0.4.3](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.4.2...private-service-connect-v0.4.3) (2023-10-25)


### Bug Fixes

* disable managed prometheus ([4e1f5e4](https://github.com/cvs-health-source-code/terraform-gke/commit/4e1f5e42427edb840764ebeaee4b00106cc13543))

## [0.4.2](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.4.1...private-service-connect-v0.4.2) (2023-10-24)


### Bug Fixes

* module references, clean up, pt2 ([12f0b1e](https://github.com/cvs-health-source-code/terraform-gke/commit/12f0b1ed91b42a0cf0b2be5f68cc82c5a16a675b))

## [0.4.1](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.4.0...private-service-connect-v0.4.1) (2023-10-24)


### Bug Fixes

* module references, examples, clean up ([642e1d4](https://github.com/cvs-health-source-code/terraform-gke/commit/642e1d44ba348fd075091ff756ffddcd05013b86))

## [0.4.0](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.3.1...private-service-connect-v0.4.0) (2023-10-24)


### Features

* disable managed prom and update default labels ([#63](https://github.com/cvs-health-source-code/terraform-gke/issues/63)) ([78479f0](https://github.com/cvs-health-source-code/terraform-gke/commit/78479f0665546c89f0adc05801096a1573c67220))

## [0.3.1](https://github.com/cvs-health-source-code/terraform-gke/compare/private-service-connect-v0.3.0...private-service-connect-v0.3.1) (2023-10-23)


### Bug Fixes

* rename versions.tf files ([c73a23c](https://github.com/cvs-health-source-code/terraform-gke/commit/c73a23cc3407180b26c237638a9459101b2b340f))
* test ([f77ebab](https://github.com/cvs-health-source-code/terraform-gke/commit/f77ebab6db6bfa6755790300aec7c32f301cb33f))
* update module name of each module ([be5fdc7](https://github.com/cvs-health-source-code/terraform-gke/commit/be5fdc790d94d75c5fbbc9a228670e11dc76a728))
* version format ([4bdb205](https://github.com/cvs-health-source-code/terraform-gke/commit/4bdb20502c79931e2bf48b876063b42a574a901c))

## [0.3.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.2.0...v0.3.0) (2023-10-23)


### Features

* add label for psc and add vpc peer module ([dd275e7](https://github.com/cvs-health-source-code/terraform-gke/commit/dd275e7cfba0fd19684c26464b4184c7d24c8dad))


### Bug Fixes

* release please mono repo with sha in config ([8ace812](https://github.com/cvs-health-source-code/terraform-gke/commit/8ace812e40096bb9caad3d0ffbe3898b77c2f6f2))
* test release-please ([d4c9500](https://github.com/cvs-health-source-code/terraform-gke/commit/d4c95006e2572f6d94d7248834815d9fbc0dd508))
* testing release mono repo ([39586d1](https://github.com/cvs-health-source-code/terraform-gke/commit/39586d13bc6985fc0f200e98f9b8b70ba4da6308))
* testing release mono repo with sha in manifest ([9f8733f](https://github.com/cvs-health-source-code/terraform-gke/commit/9f8733fa75767a7e7b3726701ad680724588eac9))
* testing release please, clean up ([5e6183c](https://github.com/cvs-health-source-code/terraform-gke/commit/5e6183c5e6092e26b4ef7affd99bc1410f5a46a4))
* update readme, test release-please ([174b577](https://github.com/cvs-health-source-code/terraform-gke/commit/174b5776c84c94e96f3f5215409e4fa9a95e6846))

## [0.2.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.1.0...v0.2.0) (2023-10-23)


### Features

* add label for psc and add vpc peer module ([dd275e7](https://github.com/cvs-health-source-code/terraform-gke/commit/dd275e7cfba0fd19684c26464b4184c7d24c8dad))


### Bug Fixes

* release please mono repo with sha in config ([8ace812](https://github.com/cvs-health-source-code/terraform-gke/commit/8ace812e40096bb9caad3d0ffbe3898b77c2f6f2))
* testing release mono repo ([39586d1](https://github.com/cvs-health-source-code/terraform-gke/commit/39586d13bc6985fc0f200e98f9b8b70ba4da6308))
* testing release mono repo with sha in manifest ([9f8733f](https://github.com/cvs-health-source-code/terraform-gke/commit/9f8733fa75767a7e7b3726701ad680724588eac9))
* testing release please, clean up ([5e6183c](https://github.com/cvs-health-source-code/terraform-gke/commit/5e6183c5e6092e26b4ef7affd99bc1410f5a46a4))
* update readme, test release-please ([174b577](https://github.com/cvs-health-source-code/terraform-gke/commit/174b5776c84c94e96f3f5215409e4fa9a95e6846))

## 1.0.0 (2023-10-10)


### Features

* add module versioning ([ef08eb9](https://github.com/cvs-health-source-code/terraform-gke/commit/ef08eb9914fa639110181b08249a3a8e0c17ca5d))
* adding release-please ([#10](https://github.com/cvs-health-source-code/terraform-gke/issues/10)) ([454f4d5](https://github.com/cvs-health-source-code/terraform-gke/commit/454f4d5ffb1bdb9da0dc033a9f128e94feba9e5d))
* test ([#23](https://github.com/cvs-health-source-code/terraform-gke/issues/23)) ([6fd9069](https://github.com/cvs-health-source-code/terraform-gke/commit/6fd90698ea0b8350ed82e3715857724fce8e1077))
* test release ([c97073c](https://github.com/cvs-health-source-code/terraform-gke/commit/c97073c446e56d15f5df856854368c21441ece74))
* test release again ([8c56b9e](https://github.com/cvs-health-source-code/terraform-gke/commit/8c56b9e9108ab208edb11c662d3aab8b26a0dee9))
* testing feature bump with release-please ([#16](https://github.com/cvs-health-source-code/terraform-gke/issues/16)) ([77af23b](https://github.com/cvs-health-source-code/terraform-gke/commit/77af23bcbc61e6be250e6dfb24502410d74652fe))
* upgrade to google provider version 5.0.0 ([10e73e5](https://github.com/cvs-health-source-code/terraform-gke/commit/10e73e53bfca6319c1a42fc28d4e175ebe68f1c1))


### Bug Fixes

* adding info about release-please to README ([#14](https://github.com/cvs-health-source-code/terraform-gke/issues/14)) ([c277bfa](https://github.com/cvs-health-source-code/terraform-gke/commit/c277bfa3c8c02d4789f8e880f51ac0274ad3de8b))
* google provider version ([2ecaa6b](https://github.com/cvs-health-source-code/terraform-gke/commit/2ecaa6bee13c56ce9a9cd617a84097b70139ff9b))
* google provider version ([4bf35c7](https://github.com/cvs-health-source-code/terraform-gke/commit/4bf35c776b3fbaf07a14dc0b6151818327dcb19e))
* google provider version ([c492494](https://github.com/cvs-health-source-code/terraform-gke/commit/c49249469d18734c19597134f5d57052ea29c788))
* google provider version ([9f007fa](https://github.com/cvs-health-source-code/terraform-gke/commit/9f007fae703afd77e5a7af6a1ec7947b9b77e4ed))
* remove beta provider ([f6a680d](https://github.com/cvs-health-source-code/terraform-gke/commit/f6a680df541a6580300c33c4daa47a62709398d0))
* swapping terraform to simple ([#17](https://github.com/cvs-health-source-code/terraform-gke/issues/17)) ([00b8c89](https://github.com/cvs-health-source-code/terraform-gke/commit/00b8c89181a623617faa87a78cc32a255a2a151d))
* test release ([78014b0](https://github.com/cvs-health-source-code/terraform-gke/commit/78014b08d031ff7381688cef01e7f45d50902f60))
* test release ([0298c29](https://github.com/cvs-health-source-code/terraform-gke/commit/0298c29a447e4134449a407ce025e303746585cb))
* test release ([9348f7d](https://github.com/cvs-health-source-code/terraform-gke/commit/9348f7dd2884e53fbdc32e59abdc1d3cc6670b61))
* test release ([6c82fe8](https://github.com/cvs-health-source-code/terraform-gke/commit/6c82fe8ee78ee7608247dcea5ada2bcf145429b3))
* test release ([fec401e](https://github.com/cvs-health-source-code/terraform-gke/commit/fec401ead2ef43d8870bd500561d2165e90793fc))
* test release ([2aea79d](https://github.com/cvs-health-source-code/terraform-gke/commit/2aea79dad2a1e3bb02bebca3427e5ebfdbe86d84))
* test release ([76857b4](https://github.com/cvs-health-source-code/terraform-gke/commit/76857b4a4bf38aee70b3beaa1da5af440268395e))
* test release ([d42a681](https://github.com/cvs-health-source-code/terraform-gke/commit/d42a68171fb054d504733d9ea05798a6d71639c8))
* test release ([b21649c](https://github.com/cvs-health-source-code/terraform-gke/commit/b21649cd276cd8c75ab78270215911b38a61ae3b))
* test release ([69d3377](https://github.com/cvs-health-source-code/terraform-gke/commit/69d3377e97b6704b1f2ef17a42a877316c99176c))
* test release ([52d0795](https://github.com/cvs-health-source-code/terraform-gke/commit/52d0795dac010736a21c47eb1bb9786b15d1dc65))
* test release ([94ac152](https://github.com/cvs-health-source-code/terraform-gke/commit/94ac1527c202e3760f5c0456ed2d6b16ae3a1ed1))
* test release ([e619f10](https://github.com/cvs-health-source-code/terraform-gke/commit/e619f10c56a01cbfc8ed65ee3a249ef1065223e6))
* test release ([95374f1](https://github.com/cvs-health-source-code/terraform-gke/commit/95374f171190986b63dcc74a18f518f4629dcd7e))
* test release ([c57f5b4](https://github.com/cvs-health-source-code/terraform-gke/commit/c57f5b46251a74cf3057c86cca5738574b3f48fb))
* test release please monorepo tag ([06fb8f4](https://github.com/cvs-health-source-code/terraform-gke/commit/06fb8f47bfc824155c659ff85379fde1375f4a7b))
* test release please monorepo tag ([a0662c5](https://github.com/cvs-health-source-code/terraform-gke/commit/a0662c522f63304ba74df2ae49b6a50caadc2eee))
* update release label ([357c7d6](https://github.com/cvs-health-source-code/terraform-gke/commit/357c7d6ae523674320b8ddc4fdba33e48a8f207c))
* update to 4.84.0 ([6a2d0b6](https://github.com/cvs-health-source-code/terraform-gke/commit/6a2d0b6c5cd9ea7b48aade1e3cbbdc4ce3244184))
* Update versions.tf ([#18](https://github.com/cvs-health-source-code/terraform-gke/issues/18)) ([4ead4bd](https://github.com/cvs-health-source-code/terraform-gke/commit/4ead4bd7b878a8be421bfed5bae06e38aab83573))

## [0.5.0](https://github.com/cvs-health-source-code/terraform-gke/compare/release-please-action-v0.4.0...release-please-action-v0.5.0) (2023-10-10)


### Features

* add module versioning ([ef08eb9](https://github.com/cvs-health-source-code/terraform-gke/commit/ef08eb9914fa639110181b08249a3a8e0c17ca5d))
* adding release-please ([#10](https://github.com/cvs-health-source-code/terraform-gke/issues/10)) ([454f4d5](https://github.com/cvs-health-source-code/terraform-gke/commit/454f4d5ffb1bdb9da0dc033a9f128e94feba9e5d))
* test ([#23](https://github.com/cvs-health-source-code/terraform-gke/issues/23)) ([6fd9069](https://github.com/cvs-health-source-code/terraform-gke/commit/6fd90698ea0b8350ed82e3715857724fce8e1077))
* test release ([c97073c](https://github.com/cvs-health-source-code/terraform-gke/commit/c97073c446e56d15f5df856854368c21441ece74))
* test release again ([8c56b9e](https://github.com/cvs-health-source-code/terraform-gke/commit/8c56b9e9108ab208edb11c662d3aab8b26a0dee9))
* testing feature bump with release-please ([#16](https://github.com/cvs-health-source-code/terraform-gke/issues/16)) ([77af23b](https://github.com/cvs-health-source-code/terraform-gke/commit/77af23bcbc61e6be250e6dfb24502410d74652fe))
* upgrade to google provider version 5.0.0 ([10e73e5](https://github.com/cvs-health-source-code/terraform-gke/commit/10e73e53bfca6319c1a42fc28d4e175ebe68f1c1))


### Bug Fixes

* adding info about release-please to README ([#14](https://github.com/cvs-health-source-code/terraform-gke/issues/14)) ([c277bfa](https://github.com/cvs-health-source-code/terraform-gke/commit/c277bfa3c8c02d4789f8e880f51ac0274ad3de8b))
* google provider version ([2ecaa6b](https://github.com/cvs-health-source-code/terraform-gke/commit/2ecaa6bee13c56ce9a9cd617a84097b70139ff9b))
* google provider version ([4bf35c7](https://github.com/cvs-health-source-code/terraform-gke/commit/4bf35c776b3fbaf07a14dc0b6151818327dcb19e))
* google provider version ([c492494](https://github.com/cvs-health-source-code/terraform-gke/commit/c49249469d18734c19597134f5d57052ea29c788))
* google provider version ([9f007fa](https://github.com/cvs-health-source-code/terraform-gke/commit/9f007fae703afd77e5a7af6a1ec7947b9b77e4ed))
* remove beta provider ([f6a680d](https://github.com/cvs-health-source-code/terraform-gke/commit/f6a680df541a6580300c33c4daa47a62709398d0))
* swapping terraform to simple ([#17](https://github.com/cvs-health-source-code/terraform-gke/issues/17)) ([00b8c89](https://github.com/cvs-health-source-code/terraform-gke/commit/00b8c89181a623617faa87a78cc32a255a2a151d))
* test release ([78014b0](https://github.com/cvs-health-source-code/terraform-gke/commit/78014b08d031ff7381688cef01e7f45d50902f60))
* test release ([0298c29](https://github.com/cvs-health-source-code/terraform-gke/commit/0298c29a447e4134449a407ce025e303746585cb))
* test release ([9348f7d](https://github.com/cvs-health-source-code/terraform-gke/commit/9348f7dd2884e53fbdc32e59abdc1d3cc6670b61))
* test release ([6c82fe8](https://github.com/cvs-health-source-code/terraform-gke/commit/6c82fe8ee78ee7608247dcea5ada2bcf145429b3))
* test release ([fec401e](https://github.com/cvs-health-source-code/terraform-gke/commit/fec401ead2ef43d8870bd500561d2165e90793fc))
* test release ([2aea79d](https://github.com/cvs-health-source-code/terraform-gke/commit/2aea79dad2a1e3bb02bebca3427e5ebfdbe86d84))
* test release ([76857b4](https://github.com/cvs-health-source-code/terraform-gke/commit/76857b4a4bf38aee70b3beaa1da5af440268395e))
* test release ([d42a681](https://github.com/cvs-health-source-code/terraform-gke/commit/d42a68171fb054d504733d9ea05798a6d71639c8))
* test release ([b21649c](https://github.com/cvs-health-source-code/terraform-gke/commit/b21649cd276cd8c75ab78270215911b38a61ae3b))
* test release ([69d3377](https://github.com/cvs-health-source-code/terraform-gke/commit/69d3377e97b6704b1f2ef17a42a877316c99176c))
* test release ([52d0795](https://github.com/cvs-health-source-code/terraform-gke/commit/52d0795dac010736a21c47eb1bb9786b15d1dc65))
* test release ([94ac152](https://github.com/cvs-health-source-code/terraform-gke/commit/94ac1527c202e3760f5c0456ed2d6b16ae3a1ed1))
* test release ([e619f10](https://github.com/cvs-health-source-code/terraform-gke/commit/e619f10c56a01cbfc8ed65ee3a249ef1065223e6))
* test release ([95374f1](https://github.com/cvs-health-source-code/terraform-gke/commit/95374f171190986b63dcc74a18f518f4629dcd7e))
* test release ([c57f5b4](https://github.com/cvs-health-source-code/terraform-gke/commit/c57f5b46251a74cf3057c86cca5738574b3f48fb))
* test release please monorepo tag ([06fb8f4](https://github.com/cvs-health-source-code/terraform-gke/commit/06fb8f47bfc824155c659ff85379fde1375f4a7b))
* test release please monorepo tag ([a0662c5](https://github.com/cvs-health-source-code/terraform-gke/commit/a0662c522f63304ba74df2ae49b6a50caadc2eee))
* update to 4.84.0 ([6a2d0b6](https://github.com/cvs-health-source-code/terraform-gke/commit/6a2d0b6c5cd9ea7b48aade1e3cbbdc4ce3244184))
* Update versions.tf ([#18](https://github.com/cvs-health-source-code/terraform-gke/issues/18)) ([4ead4bd](https://github.com/cvs-health-source-code/terraform-gke/commit/4ead4bd7b878a8be421bfed5bae06e38aab83573))

## [0.4.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.3.0...v0.4.0) (2023-06-12)


### Features

* add module versioning ([ef08eb9](https://github.com/cvs-health-source-code/terraform-gke/commit/ef08eb9914fa639110181b08249a3a8e0c17ca5d))

## [0.3.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.2.1...v0.3.0) (2023-06-12)


### Features

* test ([#23](https://github.com/cvs-health-source-code/terraform-gke/issues/23)) ([6fd9069](https://github.com/cvs-health-source-code/terraform-gke/commit/6fd90698ea0b8350ed82e3715857724fce8e1077))

## [0.2.1](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.2.0...v0.2.1) (2023-06-07)


### Bug Fixes

* Update versions.tf ([#18](https://github.com/cvs-health-source-code/terraform-gke/issues/18)) ([4ead4bd](https://github.com/cvs-health-source-code/terraform-gke/commit/4ead4bd7b878a8be421bfed5bae06e38aab83573))

## [0.2.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.1.0...v0.2.0) (2023-06-07)


### Features

* testing feature bump with release-please ([#16](https://github.com/cvs-health-source-code/terraform-gke/issues/16)) ([77af23b](https://github.com/cvs-health-source-code/terraform-gke/commit/77af23bcbc61e6be250e6dfb24502410d74652fe))


### Bug Fixes

* adding info about release-please to README ([#14](https://github.com/cvs-health-source-code/terraform-gke/issues/14)) ([c277bfa](https://github.com/cvs-health-source-code/terraform-gke/commit/c277bfa3c8c02d4789f8e880f51ac0274ad3de8b))
* swapping terraform to simple ([#17](https://github.com/cvs-health-source-code/terraform-gke/issues/17)) ([00b8c89](https://github.com/cvs-health-source-code/terraform-gke/commit/00b8c89181a623617faa87a78cc32a255a2a151d))

## 0.1.0 (2023-06-06)


### Features

* adding release-please ([#10](https://github.com/cvs-health-source-code/terraform-gke/issues/10)) ([454f4d5](https://github.com/cvs-health-source-code/terraform-gke/commit/454f4d5ffb1bdb9da0dc033a9f128e94feba9e5d))
