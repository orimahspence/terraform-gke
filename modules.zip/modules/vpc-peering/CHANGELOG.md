# Changelog

## [0.8.0](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.10...vpc-peering-v0.8.0) (2025-02-13)


### Features

* set the default max pods per node 32 ([#158](https://github.com/cvs-health-source-code/terraform-gke/issues/158)) ([23b53f3](https://github.com/cvs-health-source-code/terraform-gke/commit/23b53f3d6f058eca781660598349624411a7c40e))


### Bug Fixes

* trigger the commit set max pods per node for version ([#160](https://github.com/cvs-health-source-code/terraform-gke/issues/160)) ([741ac73](https://github.com/cvs-health-source-code/terraform-gke/commit/741ac73a3b3b119f3a17c05e7c180244eef668bc))

## [0.7.10](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.9...vpc-peering-v0.7.10) (2024-12-17)


### Bug Fixes

* logging variant in all modules and typo on private-service-connect ([6b472ec](https://github.com/cvs-health-source-code/terraform-gke/commit/6b472ecaac44a6b00d75d63008509c4281af7262))

## [0.7.9](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.8...vpc-peering-v0.7.9) (2024-03-07)


### Bug Fixes

* update default max pods per node ([#106](https://github.com/cvs-health-source-code/terraform-gke/issues/106)) ([be38fe7](https://github.com/cvs-health-source-code/terraform-gke/commit/be38fe7a9cfa0273aa0e7275315c478dd6d36f3b))

## [0.7.8](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.7...vpc-peering-v0.7.8) (2024-01-18)


### Bug Fixes

* demo for jfrog module source ([#103](https://github.com/cvs-health-source-code/terraform-gke/issues/103)) ([470d22f](https://github.com/cvs-health-source-code/terraform-gke/commit/470d22f285875f867e78acdd2ec073395dda913e))

## [0.7.7](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.6...vpc-peering-v0.7.7) (2024-01-09)


### Bug Fixes

* set cluster name as default tag for insurance-vpc clusters ([#98](https://github.com/cvs-health-source-code/terraform-gke/issues/98)) ([288efb0](https://github.com/cvs-health-source-code/terraform-gke/commit/288efb075ee4ced1cedfe7c1df41625aa12cd49a))

## [0.7.6](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.5...vpc-peering-v0.7.6) (2023-12-08)


### Bug Fixes

* check for non-prod branch name for centralized cmek ([7740007](https://github.com/cvs-health-source-code/terraform-gke/commit/7740007450315c10ec4d0eaefcc8237d32b9f6e7))

## [0.7.5](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.4...vpc-peering-v0.7.5) (2023-12-01)


### Bug Fixes

* update module version in examples ([#87](https://github.com/cvs-health-source-code/terraform-gke/issues/87)) ([17e1a43](https://github.com/cvs-health-source-code/terraform-gke/commit/17e1a4360352cb8867e0cad45cdbbe86a318069b))

## [0.7.4](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.3...vpc-peering-v0.7.4) (2023-11-30)


### Bug Fixes

* bugfix, rollback zscaler prod tags ([#84](https://github.com/cvs-health-source-code/terraform-gke/issues/84)) ([bee0252](https://github.com/cvs-health-source-code/terraform-gke/commit/bee0252ffac3240746cf1d3950395c1a26799ff6))
* remove local ssd creation option from main module ([#85](https://github.com/cvs-health-source-code/terraform-gke/issues/85)) ([69fa2a0](https://github.com/cvs-health-source-code/terraform-gke/commit/69fa2a0b321f059d62e3f67892feba1991ad3ca4))

## [0.7.3](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.2...vpc-peering-v0.7.3) (2023-11-22)


### Bug Fixes

* fix and publish to jfrog ([73843c8](https://github.com/cvs-health-source-code/terraform-gke/commit/73843c8d285bdc617b158ffc4e67bd6a0bc01948))

## [0.7.2](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.1...vpc-peering-v0.7.2) (2023-11-22)


### Bug Fixes

* debug publish to jfrog ([d2e5d47](https://github.com/cvs-health-source-code/terraform-gke/commit/d2e5d47a47ca1bb294bf043b7a67f8a4cf58d9d5))
* debug publish to jfrog ([24a63d6](https://github.com/cvs-health-source-code/terraform-gke/commit/24a63d608cab8103e4e95f028e9b11e6e8a6bd71))

## [0.7.1](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.7.0...vpc-peering-v0.7.1) (2023-11-22)


### Bug Fixes

* test publish to jfrog ([7987453](https://github.com/cvs-health-source-code/terraform-gke/commit/79874538f716202f6231da25f2928b4cc875e914))

## [0.7.0](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.6.3...vpc-peering-v0.7.0) (2023-11-22)


### Features

* initial terraform zscaler tagging plan ([#77](https://github.com/cvs-health-source-code/terraform-gke/issues/77)) ([fe5087a](https://github.com/cvs-health-source-code/terraform-gke/commit/fe5087ab79d18191b435bd5a87eb43cb4eb3b326))

## [0.6.3](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.6.2...vpc-peering-v0.6.3) (2023-11-03)


### Bug Fixes

* sync changes ([5dab5fc](https://github.com/cvs-health-source-code/terraform-gke/commit/5dab5fcae49d94d96dc77e478feedee254bbbbde))

## [0.6.2](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.6.1...vpc-peering-v0.6.2) (2023-10-24)


### Bug Fixes

* module references, clean up, pt2 ([12f0b1e](https://github.com/cvs-health-source-code/terraform-gke/commit/12f0b1ed91b42a0cf0b2be5f68cc82c5a16a675b))

## [0.6.1](https://github.com/cvs-health-source-code/terraform-gke/compare/vpc-peering-v0.6.0...vpc-peering-v0.6.1) (2023-10-23)


### Bug Fixes

* rename versions.tf files ([c73a23c](https://github.com/cvs-health-source-code/terraform-gke/commit/c73a23cc3407180b26c237638a9459101b2b340f))
* test ([f77ebab](https://github.com/cvs-health-source-code/terraform-gke/commit/f77ebab6db6bfa6755790300aec7c32f301cb33f))
* update module name of each module ([be5fdc7](https://github.com/cvs-health-source-code/terraform-gke/commit/be5fdc790d94d75c5fbbc9a228670e11dc76a728))
* version format ([4bdb205](https://github.com/cvs-health-source-code/terraform-gke/commit/4bdb20502c79931e2bf48b876063b42a574a901c))

## [0.6.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.5.0...v0.6.0) (2023-10-23)


### Features

* add label for psc and add vpc peer module ([dd275e7](https://github.com/cvs-health-source-code/terraform-gke/commit/dd275e7cfba0fd19684c26464b4184c7d24c8dad))

## [0.5.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.4.0...v0.5.0) (2023-10-23)


### Features

* add label for psc and add vpc peer module ([dd275e7](https://github.com/cvs-health-source-code/terraform-gke/commit/dd275e7cfba0fd19684c26464b4184c7d24c8dad))

## [0.4.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.3.0...v0.4.0) (2023-06-12)


### Features

* add module versioning ([ef08eb9](https://github.com/cvs-health-source-code/terraform-gke/commit/ef08eb9914fa639110181b08249a3a8e0c17ca5d))

## [0.3.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.2.1...v0.3.0) (2023-06-12)


### Features

* test ([#23](https://github.com/cvs-health-source-code/terraform-gke/issues/23)) ([6fd9069](https://github.com/cvs-health-source-code/terraform-gke/commit/6fd90698ea0b8350ed82e3715857724fce8e1077))

## [0.2.1](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.2.0...v0.2.1) (2023-06-07)


### Bug Fixes

* Update versions.tf ([#18](https://github.com/cvs-health-source-code/terraform-gke/issues/18)) ([4ead4bd](https://github.com/cvs-health-source-code/terraform-gke/commit/4ead4bd7b878a8be421bfed5bae06e38aab83573))

## [0.2.0](https://github.com/cvs-health-source-code/terraform-gke/compare/v0.1.0...v0.2.0) (2023-06-07)


### Features

* testing feature bump with release-please ([#16](https://github.com/cvs-health-source-code/terraform-gke/issues/16)) ([77af23b](https://github.com/cvs-health-source-code/terraform-gke/commit/77af23bcbc61e6be250e6dfb24502410d74652fe))


### Bug Fixes

* adding info about release-please to README ([#14](https://github.com/cvs-health-source-code/terraform-gke/issues/14)) ([c277bfa](https://github.com/cvs-health-source-code/terraform-gke/commit/c277bfa3c8c02d4789f8e880f51ac0274ad3de8b))
* swapping terraform to simple ([#17](https://github.com/cvs-health-source-code/terraform-gke/issues/17)) ([00b8c89](https://github.com/cvs-health-source-code/terraform-gke/commit/00b8c89181a623617faa87a78cc32a255a2a151d))

## 0.1.0 (2023-06-06)


### Features

* adding release-please ([#10](https://github.com/cvs-health-source-code/terraform-gke/issues/10)) ([454f4d5](https://github.com/cvs-health-source-code/terraform-gke/commit/454f4d5ffb1bdb9da0dc033a9f128e94feba9e5d))
